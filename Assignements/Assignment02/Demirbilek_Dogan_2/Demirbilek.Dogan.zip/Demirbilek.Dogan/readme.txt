**Ulysses compiler and openmp info**

gcc compiler 4.9 patchevel 2
OpenMP supported version is 4.0


**My computer architecture**

Architecture:        x86_64
CPU op-mode(s):      32-bit, 64-bit
Byte Order:          Little Endian
CPU(s):              8
On-line CPU(s) list: 0-7
Thread(s) per core:  2
Core(s) per socket:  4
Socket(s):           1
NUMA node(s):        1
Vendor ID:           GenuineIntel
CPU family:          6
Model:               60
Model name:          Intel(R) Core(TM) i7-4720HQ CPU @ 2.60GHz
Stepping:            3
CPU MHz:             2594.591
CPU max MHz:         3600,0000
CPU min MHz:         800,0000
BogoMIPS:            5187.69
Virtualization:      VT-x
L1d cache:           32K
L1i cache:           32K
L2 cache:            256K
L3 cache:            6144K
NUMA node0 CPU(s):   0-7

gcc (Ubuntu 7.4.0-1ubuntu1~18.04.1) 7.4.0
	

Python plot scripts which are asked throughout the sections. In order to run them from the terminal python script_name will be sufficient.

	*Important note, for the scripts output or input files should be in same directory.*


For all programs:

Python 3.7.3 :: Anaconda, Inc. (4.7.2)
numpy 1.17.4
matplotlib: 3.1.1

packages are used.
